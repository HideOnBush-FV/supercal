package com.toyako.supercal;

import java.util.Random;

public class Check {
	static int[][] op= new int[4][3];
	static boolean co=false;
	static int [] ori = new int [6];
	static String help="";
	
	public static int[] gene()
	{
	int i=0,j=0;
	int x;
gene:
	for(;i<6;i++,j=0)
	{
		x = new Random().nextInt(60);
		ori[i]=x;
		while(j<i)
		{
			if(ori[j]==ori[i])
			{
				System.out.println(" repeated ,input again:");
				i--;
				continue gene;
			}
			j++;
		}
		System.out.println("-------------->>now a[i] = "+ori[i]);
	}
	return ori;
	}
	
	public static int[] check()
	{
		do
		{
			gene();
		}
		while(!prob(ori));
		return ori;
	}

	static void g(int a[],int b[],int n,int i,int j)
	{
		int x,y;
		for(x=0,y=1;x<n;x++)
		{
			if(x==i||x==j)continue;
			b[y++]=a[x];
		}
		op[5-n][0]=a[i];
		op[5-n][1]=a[j];
	}

	static void f(int a[],int n,int m)
	{
		int b[]=new int[4],i,j,t;
		if(n==1&&a[0]==m) co=true;
		for(i=0;i<n-1;i++)
		{
			for(j=i+1;j<n;j++)
			{
				for(t=1;t<=6;t++)
				{
					switch(t)
					{
					case 1:g(a,b,n,i,j);
						b[0]=a[i]+a[j];
						op[5-n][2]=t;
						f(b,n-1,m);
						if(co) return;
						break;
					case 2:g(a,b,n,i,j);
						b[0]=a[i]-a[j];
						op[5-n][2]=t;
						f(b,n-1,m);
						if(co) return;
						break;
					case 3:g(a,b,n,i,j);
						b[0]=a[i]*a[j];
						op[5-n][2]=t;
						f(b,n-1,m);
						if(co) return;
						break;
					case 4:
						if(a[j]!=0&&a[i]%a[j]==0)
						{
							g(a,b,n,i,j);
							b[0]=a[i]/a[j];
							op[5-n][2]=t; 
							f(b,n-1,m);
							if(co)return;
						}
						break;
					case 5:g(a,b,n,i,j);
						b[0]=a[j]-a[i];
						op[5-n][2]=t;
						f(b,n-1,m);
						if(co) return;
						break;
					case 6:
						if(a[i]!=0&&a[j]%a[i]==0&&a[j]>a[i])
						{
							g(a,b,n,i,j);
							b[0]=a[j]/a[i];
							op[5-n][2]=t;
							f(b,n-1,m);
							if(co)return;
						}
						break;
					}
				}
			}
		}
	}

	static void h(int a[],int n,int x,int y,int h)
	{
		int i,j;
		int b[] = new int[5];
		boolean bx=false,by=false;
		for(i=0,j=0;i<n;i++)
		{
			if(a[i]==x&&bx==false)
			{
				bx=true;
				continue;
			}
			if(a[i]==y&&by==false)
			{
				by=true;
				continue;
			}
			b[j++]=a[i];
		}
		for(i=0;i<n-1;i++)
			a[i+1]=b[i];
		a[0]=h;
	}

	static boolean prob(int orinum[])
	{
		int i,j,b;
		int a[] = new int[5];
		for(i=0;i<5;i++)
		{
			a[i]=orinum[i]/4+1;
		}
		b = orinum[5]/4+1;
		f(a,5,b);
		if(co)
		{
			for(i=0;i<4;i++)
			{
				switch(op[i][2])
				{
				case 1:
					h(a,5-i,op[i][0],op[i][1],op[i][0]+op[i][1]);
					break;
				case 2:
					h(a,5-i,op[i][0],op[i][1],op[i][0]-op[i][1]);
					break;
				case 3:
					h(a,5-i,op[i][0],op[i][1],op[i][0]*op[i][1]);
					break;
				case 4:
					h(a,5-i,op[i][0],op[i][1],op[i][0]/op[i][1]);
					break;
				case 5:
					h(a,5-i,op[i][0],op[i][1],op[i][1]-op[i][0]);
					break;
				case 6:
					h(a,5-i,op[i][0],op[i][1],op[i][1]/op[i][0]);
					break;
				}
			}
			return true;
		}
		else return false;
	}


	static String help(int orinum[])
	{
		int i,j,b;
		int a[] = new int[5];
		co=false;
		help = "";
		for(i=0;i<5;i++)
		{
			a[i]=orinum[i]/4+1;
		}
		b = orinum[5]/4+1;
		f(a,5,b);
		if(co)
		{
			for(i=0;i<4;i++)
			{
				for(j=0;j<5-i;j++)
					help += a[j] +" ";
				help +="\n"+"运算";
				switch(op[i][2])
				{
				case 1:
					help += op[i][0]+"+"+op[i][1]+"="+(op[i][0]+op[i][1])+"\n";
					h(a,5-i,op[i][0],op[i][1],op[i][0]+op[i][1]);
					break;
				case 2:
					help += op[i][0]+"-"+op[i][1]+"="+(op[i][0]-op[i][1])+"\n";
					h(a,5-i,op[i][0],op[i][1],op[i][0]-op[i][1]);
					break;
				case 3:
					help += op[i][0]+"*"+op[i][1]+"="+(op[i][0]*op[i][1])+"\n";
					h(a,5-i,op[i][0],op[i][1],op[i][0]*op[i][1]);
					break;
				case 4:
					help += op[i][0]+"÷"+op[i][1]+"="+(op[i][0]/op[i][1])+"\n";
					h(a,5-i,op[i][0],op[i][1],op[i][0]/op[i][1]);
					break;
				case 5:
					help += op[i][1]+"-"+op[i][0]+"="+(op[i][1]-op[i][0])+"\n";
					h(a,5-i,op[i][0],op[i][1],op[i][1]-op[i][0]);
					break;
				case 6:
					help += op[i][1]+"÷"+op[i][0]+"="+(op[i][1]/op[i][0])+"\n";
					h(a,5-i,op[i][0],op[i][1],op[i][1]/op[i][0]);
					break;
				}
			}
			help += b;
		}
		else 
			help = "不能计算出结果数";
		return help;
	}
}
