package com.toyako.supercal;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class HisActivity extends ActionBarActivity {
	public static final String MUSICNUM = "com.toyako.supercal.musicnum";
	TextView showhis;
	String his;
	SharedPreferences pre;
	Button rfhis;
	Intent musicService;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_his);
		
		musicService = new Intent(this,MusicService.class);
		musicService.putExtra(MUSICNUM, 5);
		startService(musicService);
		showhis = (TextView)findViewById(R.id.showhis);
		rfhis = (Button)findViewById(R.id.rfhis);
		rfhis.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				stopService(musicService);
				Intent toMain = new Intent(HisActivity.this,MainActivity.class);
				startActivity(toMain);
				HisActivity.this.finish();
			}
			
		});
		pre = getSharedPreferences("hisinfo",Activity.MODE_PRIVATE);
		his = "最高闯关："+pre.getInt("round", 1)+"\n最高得分："+pre.getInt("score", 0);
		showhis.setText(his);
	}

	@Override
	public boolean onKeyDown(int keyCode,KeyEvent event)
	{
		if(keyCode == KeyEvent.KEYCODE_BACK)
		{
			stopService(musicService);
			Intent i = new Intent(HisActivity.this,MainActivity.class);
			startActivity(i);
			HisActivity.this.finish();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
}
