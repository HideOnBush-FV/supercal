package com.toyako.supercal;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class TrainActivity extends ActionBarActivity implements OnClickListener{
	public static final String MUSICNUM = "com.toyako.supercal.musicnum";
	static final String SCORE = "score";
	static final String ROUND = "round";
	static String his = "";
	
	public static SharedPreferences preferences;
	Editor editor;
	public int round = 1;
	public int time=100;
	public int score=0;
	public int clknum = 0;

	TextView showround,showtime,showscore,ope1,ope2,ope3,ope4;
	int picId,re,mode,music;
	int[] num,openum;
	int[] clicked = new int [8];
	int[] orinum = new int [6];
//	ImageButton augend1,addend1,re1,augend2,addend2,re2,augend3,addend3,re3,augend4,addend4,re4,
	ImageButton[] ori;
	Button[] numimages;
	TypedArray images;
	Button plus,minus,multi,divi,done,retu,toori,help;
	Button[] ope;
	Timer timer = null;
	TimerTask task = null;
	
	SoundPool soundpool;
	int soundId;
	MediaPlayer mdp = null;
	private Intent serviceIntent = new Intent("com.toyako.MusicService");
	Intent toMain;
/*
	private MediaPlayer mediaPlayer;
	public void startmusic(int music){
		if(mediaPlayer == null){
			switch(music){
			case 1:mediaPlayer = MediaPlayer.create(this, R.raw.trainmusic);break;
			case 2:mediaPlayer = MediaPlayer.create(this, R.raw.roundmusic);break;
			case 3:mediaPlayer = MediaPlayer.create(this, R.raw.sprintsoundshort);break;
			case 4:mediaPlayer = MediaPlayer.create(this, R.raw.failmusic);break;
			case 5:mediaPlayer = MediaPlayer.create(this, R.raw.hismusic);break;
			case 6:mediaPlayer = MediaPlayer.create(this, R.raw.success);break;
			case 7:mediaPlayer = MediaPlayer.create(this, R.raw.menumusic);break;
			}
			mediaPlayer.setLooping(true);
			mediaPlayer.start();
		}
	}
	
	public void stopmusic()
	{

		mediaPlayer.stop();
		mediaPlayer.release();
	}
	
	*/
//倒计时
	private Handler mHandler = new Handler(){
		public void handleMessage(Message msg){
			if(msg.arg1>=0)
			{
				showtime.setText("剩余时间："+msg.arg1);
				startTime();				
			}
			else
			{
				timer.cancel();
				di();
			}
		}
	};
	
	public void startTime(){
		timer = new Timer();
		task = new TimerTask(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
					time--;	
					Message message = mHandler.obtainMessage();
					message.arg1 = time;
					mHandler.sendMessage(message);
			}
			
		};
		timer.schedule(task,1000);
	}

	public void di()
	{
		AlertDialog.Builder builder = new AlertDialog.Builder(TrainActivity.this);
		switch(mode)
		{
		case 2:
			stopService(serviceIntent);
			music = 4;
			serviceIntent.putExtra(MUSICNUM, music);
			startService(serviceIntent);
			builder.setMessage("时间到！尚未算完哟~")
			.setCancelable(false)
			.setPositiveButton("重玩此局",
					new DialogInterface.OnClickListener() {
						
						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							stopService(serviceIntent);
							music = 2;
							serviceIntent.putExtra(MUSICNUM, music);
							startService(serviceIntent);
							
							toori();
							time = 180-round/3;
							showtime.setText("剩余时间："+time);
							startTime();
						}
					})
					.setNegativeButton("返回主目录",
							new DialogInterface.OnClickListener(){

								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									// TODO Auto-generated method stub
									toMain();
								}
						
					})
					.setNeutralButton("新开一局",
							new DialogInterface.OnClickListener() {
								
								@Override
								public void onClick(DialogInterface dialog, int which) {
									// TODO Auto-generated method stub
									stopService(serviceIntent);
									music = 2;
									serviceIntent.putExtra(MUSICNUM, music);
									startService(serviceIntent);

									init();
								}
							});
			AlertDialog alert2 = builder.create();
			alert2.show();
			break;
		case 3:
			stopService(serviceIntent);
			music = 6;
			serviceIntent.putExtra(MUSICNUM, music);
			startService(serviceIntent);
			if(score>getPreferences(Activity.MODE_PRIVATE).getInt(SCORE,0))
			{
				getPreferences(Activity.MODE_PRIVATE).edit().putInt(SCORE, score);
				if(getPreferences(Activity.MODE_PRIVATE).edit().commit())
					Toast.makeText(TrainActivity.this, "创建最高分数新纪录啦啦啦~"+score, Toast.LENGTH_SHORT).show();
			}
			builder.setMessage("时间到！~本局得分："+score)
			.setCancelable(false)
			.setPositiveButton("重新冲刺",
					new DialogInterface.OnClickListener(){

						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							stopService(serviceIntent);
							music = 3;
							serviceIntent.putExtra(MUSICNUM, music);
							startService(serviceIntent);
							
							round = 1;time = 100;score = 0;
							init();
						}
				
			})
			.setNegativeButton("返回主目录",
					new DialogInterface.OnClickListener(){

						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							toMain();
						}
				
			});
			AlertDialog alert3 = builder.create();
			alert3.show();
			break;
		}
	}
	//初始化，取得各个空间并设置监听
	private void init(){

		images = getResources().obtainTypedArray(R.array.setpic);
		num = new int[12];
		ori = new ImageButton[6];
		numimages = new Button[12];
		numimages[0] = (Button)findViewById(R.id.augend1);
		numimages[1] = (Button)findViewById(R.id.addend1);
		numimages[2] = (Button)findViewById(R.id.re1);
		numimages[3] = (Button)findViewById(R.id.augend2);
		numimages[4] = (Button)findViewById(R.id.addend2);
		numimages[5] = (Button)findViewById(R.id.re2);
		numimages[6] = (Button)findViewById(R.id.augend3);
		numimages[7] = (Button)findViewById(R.id.addend3);
		numimages[8] = (Button)findViewById(R.id.re3);
		numimages[9] = (Button)findViewById(R.id.augend4);
		numimages[10] = (Button)findViewById(R.id.addend4);
		numimages[11] = (Button)findViewById(R.id.re4);
		ori[0] = (ImageButton)findViewById(R.id.ori1);
		ori[1] = (ImageButton)findViewById(R.id.ori2);
		ori[2] = (ImageButton)findViewById(R.id.ori3);
		ori[3] = (ImageButton)findViewById(R.id.ori4);
		ori[4] = (ImageButton)findViewById(R.id.ori5);
		ori[5] = (ImageButton)findViewById(R.id.orire);
		plus = (Button)findViewById(R.id.plus);
		minus = (Button)findViewById(R.id.minus);
		multi = (Button)findViewById(R.id.multi);
		divi = (Button)findViewById(R.id.divi);
		done = (Button)findViewById(R.id.done);
		retu = (Button)findViewById(R.id.retu);
		toori = (Button)findViewById(R.id.toori);
		help = (Button)findViewById(R.id.helpcal);
		
		ope = new Button[4];
		ope[0] = (Button)findViewById(R.id.ope1);
		ope[1] = (Button)findViewById(R.id.ope2);
		ope[2] = (Button)findViewById(R.id.ope3);
		ope[3] = (Button)findViewById(R.id.ope4);
		
		openum = new int[4];
		showround = (TextView)findViewById(R.id.showround);
		showtime = (TextView)findViewById(R.id.showtime);
		showscore = (TextView)findViewById(R.id.showscore);
		
		ori[0].setOnClickListener(this);
		ori[1].setOnClickListener(this);
		ori[2].setOnClickListener(this);
		ori[3].setOnClickListener(this);
		ori[4].setOnClickListener(this);
		numimages[2].setOnClickListener(this);
		numimages[5].setOnClickListener(this);
		numimages[8].setOnClickListener(this);
		plus.setOnClickListener(this);
		minus.setOnClickListener(this);
		multi.setOnClickListener(this);
		divi.setOnClickListener(this);
		toori.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				toori();
			}});		
		done.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				check();
			}});
		retu.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				toMain();
			}});
		help.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				if(mode == 3)
				{
					Toast.makeText(TrainActivity.this, "冲刺模式不能调用帮助哟~", Toast.LENGTH_SHORT).show();
					return;
				}
				AlertDialog.Builder builder = new AlertDialog.Builder(TrainActivity.this);
					builder.setMessage(Check.help(orinum))
					.setPositiveButton("确定",
							new DialogInterface.OnClickListener() {
								
								@Override
								public void onClick(DialogInterface dialog, int which) {
									// TODO Auto-generated method stub
									init();
								}
							});
					AlertDialog alert2 = builder.create();
					alert2.show();
			}
			
		});
		
		orinum =Check.check();
		picId = images.getResourceId(orinum[0], 0);
		ori[0].setImageDrawable(getResources().getDrawable(picId));
		picId = images.getResourceId(orinum[1], 0);
		ori[1].setImageDrawable(getResources().getDrawable(picId));
		picId = images.getResourceId(orinum[2], 0);
		ori[2].setImageDrawable(getResources().getDrawable(picId));
		picId = images.getResourceId(orinum[3], 0);
		ori[3].setImageDrawable(getResources().getDrawable(picId));
		picId = images.getResourceId(orinum[4], 0);
		ori[4].setImageDrawable(getResources().getDrawable(picId));
		picId = images.getResourceId(orinum[5], 0);
		ori[5].setImageDrawable(getResources().getDrawable(picId));
		toori();
		switch(mode)
		{
		case 1:break;
		case 2:
			if(timer != null)
				timer.cancel();
			getHis();
			showtime.setText("剩余时间："+time);
			showround.setText("关数："+round);startTime();break;
		case 3:
			showscore.setText("得分："+score);
			showtime.setText("剩余时间："+time);
			showround.setText("关数："+round);
			if(timer != null)
				timer.cancel();
			
			startTime();
			break;
			default:break;
		}
		
	}
	
	//闯关模式中读取历史最高关数和
	public String getHis(){
/*		try {
			
			DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder;
			builder = builderFactory.newDocumentBuilder();
			Document document = builder.parse(getAssets().open("hismost.xml"));
			Element element = document.getDocumentElement();
			NodeList list = element.getElementsByTagName("round");
			Element r = (Element) list.item(0);
			round =  Integer.parseInt(r.getNodeValue());
			showround.append("关数："+round);
//			time = 180-round/3;
//			showtime.setText("剩余时间："+time);
//			score = Integer.parseInt(hisinfo.getElementsByTagName("score").item(0).getTextContent());
			
		}catch (ParserConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 catch (SAXException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		preferences = getSharedPreferences("hisinfo",Activity.MODE_PRIVATE);
		editor = preferences.edit();
		score = preferences.getInt(SCORE, 0);
		round = preferences.getInt(ROUND, 1);
		time = 180-round/3;
		his = "最高闯关："+round+"\n最高得分："+score;
		return his;
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_train);
		Intent intent = getIntent();
		mode = intent.getIntExtra(MainActivity.modechosen, 0);
		init();
		
		music = mode;
		serviceIntent = new Intent(this,MusicService.class);
		serviceIntent.putExtra(MUSICNUM, music);
		startService(serviceIntent);

}
	
	//计算各个算式的结果数
	public void calcu(int i)
	{
		if(i%3 == 1)
		{
			if(openum[i/3] == 0)
			{
				Toast.makeText(TrainActivity.this,"请添加运算符~",Toast.LENGTH_SHORT).show();
				return;
			}
			switch(openum[i/3])
			{
				case 1:num[i+1]=num[i-1]+num[i];break;
				case 2:num[i+1]=num[i-1]-num[i];break;
				case 3:num[i+1]=num[i-1]*num[i];break;
				case 4:if(num[i-1]%num[i]!=0)
				{
					Toast.makeText(TrainActivity.this, "不能整除请清零重新选择", Toast.LENGTH_SHORT).show();
					return;
				}
				num[i+1]=num[i-1]/num[i];break;
			}
			numimages[i+1].setText(num[i+1]+"");
		}
	}

	//点击生成的牌时在算式中显示相应数字
	public void fillblank(int view,int para)
	{
		int i = 0;
		switch(view){
		case 0:
			for(;i<12;i++)
			{
				if(num[i] == -400)
				{

					if(openum[i/3] == 0 && i%3 == 2)
					{
						continue;
					}
					else
						break;
				}
			}
			if(para>=0)
				num[i] = para/4+1;
			else
				num[i] = para/4;
			numimages[i].setText(num[i]+"");
			calcu(i);
			break;
		case 1:
			if(openum[3]!=0)
			{
				Toast.makeText(TrainActivity.this,"运算符已填满别再按咯~",Toast.LENGTH_SHORT).show();
				return;
			}
			for(i = 0 ;i<4;i++)
			{
				if(openum[i] == 0)
					break;
			}
			openum[i] = para;
			switch(para)
			{
			case 1:ope[i].setText("+");break;
			case 2:ope[i].setText("-");break;
			case 3:ope[i].setText("*");break;
			case 4:ope[i].setText("÷");break;
			}
			if(num[i*3+1] != -400)
				calcu(i*3+1);
			break;
		}
	}
	
	//检查计算出的结果数与随机生成的结果牌是否一致
	public void check()
	{
		for(int i=11;i>1;i=i-3)
		{
			if(num[i] != -400)
			{
				if(num[i]==orinum[5]/4+1)
				{
					switch(mode){
					case 2:
						if(i != 11)
						{
							Toast.makeText(TrainActivity.this, "5张牌没有全部用到哦~", Toast.LENGTH_SHORT).show();
							return;
						}
						round = round+1;
						editor.putInt(ROUND,round);
						if(editor.commit())
							Toast.makeText(TrainActivity.this, round+"", Toast.LENGTH_SHORT).show();
						break;
					case 1:
						if(i != 11)
						{
							Toast.makeText(TrainActivity.this, "5张牌没有全部用到哦~", Toast.LENGTH_SHORT).show();
							return;
						}
						break;
					case 3:
						switch(clknum)
						{
						case 2:score = score+2;break;
						case 3:score += 4;break;
						case 4:score = score + 7;break;
						case 5:score += 12;break;
						}
						preferences = getSharedPreferences("hisinfo",Activity.MODE_PRIVATE);
						if(score>preferences.getInt(SCORE, 0)){
							editor = preferences.edit();
							editor.putInt(SCORE, score);
							editor.commit();
						}
						round++;
						break;
					}
					init();
					return;
				}
				else
				{
					Toast.makeText(TrainActivity.this, "计算结果不等于生成的结果牌", Toast.LENGTH_LONG).show();
					return;
				}
			}
		}
	}
	
	public void toori()
	{
		clknum = 0;
		for(int i = 0;i<12;i++)
			numimages[i].setText(" ");
		for(int i = 0;i<12;i++)
			num[i] = -400;
		for(int i = 0;i<4;i++)
			ope[i].setText(" ");
		for(int i = 0;i<8;i++)
			clicked[i] = 0;
		for(int i = 0 ;i<4;i++){
			openum[i] = 0;	
			ope[i].getBackground().setAlpha(127);
		}
		for(int i = 0;i<12;i++)
		{
			numimages[i].setBackgroundColor(Color.rgb(209,238,238));
			numimages[i].getBackground().setAlpha(110);
		}
		for(int i = 0;i<5;i++){
			ori[i].setBackgroundColor(Color.TRANSPARENT);
		}
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		int para = -1;int view = 0;
		switch(v.getId()){
		case R.id.plus:view = 1;para = 1;break;
		case R.id.minus:view = 1;para = 2;break;
		case R.id.multi:view = 1;para = 3;break;
		case R.id.divi:view = 1;para = 4;break;
		case R.id.ori1:
			if(clicked[0] == 0 )
			{
				ori[0].setBackgroundColor(Color.GRAY);
			clicked[0] = 1;
			clknum++;
			para = orinum[0];
			}
		else
			{
			Toast.makeText(TrainActivity.this,"此牌已使用过，不可以重复使用",Toast.LENGTH_SHORT).show();
			return;
			}
			break;
		case R.id.ori2:
			if(clicked[1] == 0 )
			{
				ori[1].setBackgroundColor(Color.GRAY);
			clicked[1] = 1;
			clknum++;
			para = orinum[1];
			}
		else
			{
			Toast.makeText(TrainActivity.this,"此牌已使用过，不可以重复使用",Toast.LENGTH_SHORT).show();
			return;
			}
			break;
		case R.id.ori3:
			if(clicked[2] == 0 )
			{
				ori[2].setBackgroundColor(Color.GRAY);
			clicked[2] = 1;
			clknum++;
			para = orinum[2];
			}
		else
			{
			Toast.makeText(TrainActivity.this,"此牌已使用过，不可以重复使用",Toast.LENGTH_SHORT).show();
			return;
			}
			break;
		case R.id.ori4:
			if(clicked[3] == 0 )
			{
				ori[3].setBackgroundColor(Color.GRAY);
			clicked[3] = 1;
			clknum++;
			para = orinum[3];
			}
		else
			{
			Toast.makeText(TrainActivity.this,"此牌已使用过，不可以重复使用",Toast.LENGTH_SHORT).show();
			return;
			}
			break;
		case R.id.ori5:
			if(clicked[4] == 0 )
			{
				ori[4].setBackgroundColor(Color.GRAY);
			clicked[4] = 1;
			clknum++;
			para = orinum[4];
			}
		else
			{
			Toast.makeText(TrainActivity.this,"此牌已使用过，不可以重复使用",Toast.LENGTH_SHORT).show();
			return;
			}
			break;
		case R.id.re1:
			if(clicked[5] == 0 )
			{
				if(num[2] == -400)
				{
					Toast.makeText(TrainActivity.this, "此数未生成，不能点击哒~", Toast.LENGTH_SHORT).show();
					return;
				}
				numimages[2].setBackgroundColor(Color.GRAY);
			clicked[5] = 1;
			para = num[2]*4-1;
			}
		else
			{
			Toast.makeText(TrainActivity.this,"此牌已使用过，不可以重复使用",Toast.LENGTH_SHORT).show();
			return;
			}
			break;
		case R.id.re2:
			if(clicked[6] == 0 )
			{
				if(num[5] == -400)
				{
					Toast.makeText(TrainActivity.this, "此数未生成，不能点击哒~", Toast.LENGTH_SHORT).show();
					return;
				}
				numimages[5].setBackgroundColor(Color.GRAY);
			clicked[6] = 1;
			para = num[5]*4-1;
			}
		else
			{
			Toast.makeText(TrainActivity.this,"此牌已使用过，不可以重复使用",Toast.LENGTH_SHORT).show();
			return;
			}
			break;
		case R.id.re3:
			if(clicked[7] == 0 )
			{
				if(num[8] == -400)
				{
					Toast.makeText(TrainActivity.this, "此数未生成，不能点击哒~", Toast.LENGTH_SHORT).show();
					return;
				}
				numimages[8].setBackgroundColor(Color.GRAY);
			clicked[7] = 1;
			para = num[8]*4-1;
			}
		else
			{
			Toast.makeText(TrainActivity.this,"此牌已使用过，不可以重复使用",Toast.LENGTH_SHORT).show();
			return;
			}
			break;
		default:
		}
		fillblank(view,para);
	}
	
/*	 protected void onResume()
	 {
		 mdp = MediaPlayer.create(this, R.raw.sprintsound);
		 try {
			mdp.prepare();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 super.onResume();
	 }
	 
	 protected void onPause()
	 {
		 if(mdp != null)
		 {
			 mdp.release();
			 
		 }
		 super.onPause();
	 }
*/
	protected void toMain()
	{
		stopService(serviceIntent);
		toMain = new Intent(TrainActivity.this,MainActivity.class);
		startActivity(toMain);
		TrainActivity.this.finish();
	}
	@Override
	public boolean onKeyDown(int keyCode,KeyEvent event)
	{
		if(keyCode == KeyEvent.KEYCODE_BACK)
		{
			toMain();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
	protected void onDestroy() { 
		// TODO Auto-generated method stub
        Log.e("COMPLETELY_EXIT", "EXIT_EXIT_EXIT_EXIT_EXIT_onDestory called."); 
		super.onDestroy(); 
		}
	}
