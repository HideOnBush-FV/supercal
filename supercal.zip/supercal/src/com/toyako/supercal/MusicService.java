package com.toyako.supercal;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.util.Log;

public class MusicService extends Service {
	private MediaPlayer mediaPlayer;

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public void onStart(Intent intent,int startId){
		super.onStart(intent, startId);
		int musicnum = intent.getIntExtra("com.toyako.supercal.musicnum", startId);
		Log.e("musicnum","------->>>>"+musicnum);
		
		if(mediaPlayer == null){
			switch(musicnum){
			case 1:mediaPlayer = MediaPlayer.create(this, R.raw.trainmusic);break;
			case 2:mediaPlayer = MediaPlayer.create(this, R.raw.roundmusic);break;
			case 3:mediaPlayer = MediaPlayer.create(this, R.raw.sprintsoundshort);break;
			case 4:mediaPlayer = MediaPlayer.create(this, R.raw.failmusic);break;
			case 5:mediaPlayer = MediaPlayer.create(this, R.raw.hismusic);break;
			case 6:mediaPlayer = MediaPlayer.create(this, R.raw.success);break;
			case 7:mediaPlayer = MediaPlayer.create(this, R.raw.menumusic);break;
			}
			mediaPlayer.setLooping(true);
			mediaPlayer.start();
		}
	}
	
	public void onDestroy(){
		Log.e("SERVICE_EXIT","SERVICE_EXIT_SERVICE_EXIT_SERVICE");
		mediaPlayer.stop();
		mediaPlayer.release();
		super.onDestroy();
	}

}
