package com.toyako.supercal;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends ActionBarActivity implements OnClickListener{
	
	public static final String modechosen = "com.toyako.supercal.modechosen";
	public static final String musicnum = "com.toyako.supercal.musicnum";
	private Button train,round,sprint,help,exit,hisinfo;
	Intent musicService;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		musicService = new Intent(this,MusicService.class);
    	musicService.putExtra(musicnum, 7);
		startService(musicService);
		
		train = (Button)findViewById(R.id.trainmode);
		round = (Button)findViewById(R.id.roundmode);
		sprint = (Button)findViewById(R.id.sprintmode);
		help = (Button)findViewById(R.id.help);
		exit = (Button)findViewById(R.id.exit);
		hisinfo = (Button)findViewById(R.id.hisinfo);
		
		train.setOnClickListener(this);
		round.setOnClickListener(this);
		sprint.setOnClickListener(this);
		help.setOnClickListener(this);
		exit.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				stopService(musicService);
				MainActivity.this.finish();
			}
			
		});
		hisinfo.setOnClickListener(this);
		}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		int mode = 0;
		Intent intent;
		switch(v.getId()){
		case R.id.trainmode:mode = 1;
		intent = new Intent(this,TrainActivity.class);break;   
		case R.id.roundmode:mode = 2;
		intent = new Intent(this,TrainActivity.class);break;   
		case R.id.sprintmode:mode = 3;
		intent = new Intent(this,TrainActivity.class);break;   
		case R.id.help:
			intent = new Intent(this,HelpActivity.class);break; 
		case R.id.hisinfo:mode = 5;
		intent = new Intent(this,HisActivity.class);break;
		default:       
			intent = new Intent(this,HelpActivity.class);break;                                                                                
		}
		intent.putExtra(modechosen, mode);
    	stopService(musicService);
		startActivity(intent);
		MainActivity.this.finish();
	}
	
	@Override
	public boolean onKeyDown(int keyCode,KeyEvent event)
	{
		if(keyCode == KeyEvent.KEYCODE_BACK)
		{
			stopService(musicService);
			MainActivity.this.finish();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}
	
    @Override  
    protected void onDestroy() {  
        super.onDestroy();  
        Log.e("COMPLETELY_EXIT", "MainActivity_EXIT_EXIT_EXIT_EXIT_EXIT_onDestory called.");  
    }  

}
