/** Automatically generated file. DO NOT MODIFY */
package com.toyako.supercal;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}